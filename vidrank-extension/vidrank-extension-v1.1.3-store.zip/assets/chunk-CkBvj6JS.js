(function(){function u(h){return!h||!Array.isArray(h)?[]:h.map(t=>{const e=t.replace(/[^a-zA-Z0-9\u0980-\u09FF]/g,"").toLowerCase();return e.startsWith("#")?e:"#"+e}).filter(t=>t.length>1)}class L{constructor(t={}){this.containerId="yt-auto-tag-sidebar",this.element=null,this.isOpen=!1,this.tags=[],this.isLoggedIn=t.isLoggedIn||!1,this.onToggleHashtag=t.onToggleHashtag||(()=>{}),this.onRegenerate=t.onRegenerate||(()=>{}),this.onInsertTags=t.onInsertTags||(()=>{}),this.init()}init(){if(document.getElementById(this.containerId)){this.element=document.getElementById(this.containerId);return}chrome.storage.sync.get({autoGenerate:!0,autoInsert:!0,hashtagMode:!1,maxTagsCount:35,preferredSeparator:","},t=>{this.createSidebar(t),this.log("Sidebar UI loaded and initialized.","info")})}createSidebar(t){const e=document.createElement("div");e.id=this.containerId,e.className="yt-sidebar-panel";let a="";this.isLoggedIn?a=`
        <!-- Header -->
        <div class="yt-sidebar-header">
          <div class="yt-sidebar-profile">
            <div class="yt-sidebar-avatar" id="yt-sidebar-avatar"><span class="yt-avatar-letter">V</span></div>
            <div class="yt-sidebar-profile-meta">
              <strong class="yt-sidebar-profile-name" id="yt-sidebar-profile-name">&mdash;</strong>
              <span class="yt-sidebar-profile-subrow">
                <span class="yt-tier-pill yt-tier-pill-free" id="yt-sidebar-tier">FREE</span>
                <span class="yt-usage-text" id="yt-sidebar-usage"></span>
              </span>
            </div>
          </div>
          <div class="yt-sidebar-title-row">
            <h2>VidRank</h2>
          </div>
          <p class="yt-sidebar-subtitle">Optimize Every Video. Unlock Better YouTube Rankings.</p>
        </div>

        <!-- Controls / Switches -->
        <div class="yt-sidebar-section">

          <div class="yt-control-row">
            <label for="yt-toggle-insert" class="yt-switch-label">
              <span>Auto Insert to Studio</span>
              <span class="yt-label-help" title="Automatically type generated tags into YouTube's Tags textfield.">?</span>
            </label>
            <label class="yt-switch">
              <input type="checkbox" id="yt-toggle-insert" ${t.autoInsert?"checked":""}>
              <span class="yt-slider"></span>
            </label>
          </div>

          <div class="yt-control-row">
            <label for="yt-toggle-hashtag" class="yt-switch-label">
              <span>Hashtag Mode</span>
              <span class="yt-label-help" title="Remove spaces and add '#' to the front of tags.">?</span>
            </label>
            <label class="yt-switch">
              <input type="checkbox" id="yt-toggle-hashtag" ${t.hashtagMode?"checked":""}>
              <span class="yt-slider"></span>
            </label>
          </div>
        </div>

        <!-- Detected Title Info -->
        <div class="yt-sidebar-section yt-info-section">
          <div class="yt-info-item">
            <span class="yt-info-key">Detected Title:</span>
            <span class="yt-info-val" id="yt-sidebar-detected-title">Waiting for video details...</span>
          </div>
          <div class="yt-info-item">
            <span class="yt-info-key">Tag Count / Limit:</span>
            <span class="yt-info-val"><strong id="yt-tag-counter">0</strong> / <span id="yt-max-tags-limit">${t.maxTagsCount}</span> tags</span>
          </div>
          <div class="yt-info-item">
            <span class="yt-info-key">Total Size:</span>
            <span class="yt-info-val"><strong id="yt-char-counter">0</strong> / 500 characters</span>
          </div>
          <div class="yt-info-item">
            <span class="yt-info-key">Last Synced:</span>
            <span class="yt-info-val" id="yt-last-update-time">-</span>
          </div>
        </div>

        <!-- Tags Container -->
        <div class="yt-sidebar-tags-section">
          <div class="yt-tags-header-row">
            <h3>Generated Tags</h3>
            <span class="yt-tags-placeholder-tip">No tags generated yet. Type a title to start.</span>
          </div>
          
          <div class="yt-chips-container" id="yt-chips-container">
            <!-- Chips injected dynamically -->
          </div>

          <!-- Add manual tag input -->
          <div class="yt-add-manual-tag-row">
            <input type="text" id="yt-manual-tag-input" placeholder="Type a custom tag and hit Enter..." />
            <button id="yt-manual-tag-add-btn" title="Add Tag">+</button>
          </div>
        </div>

        <!-- Actions Panel Footer -->
        <div class="yt-sidebar-footer">
          <button id="yt-action-regenerate" class="yt-btn yt-btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
            </svg>
            <span>Regenerate Tags</span>
          </button>
          
          <button id="yt-action-insert" class="yt-btn yt-btn-secondary">
            <span>Insert to Studio</span>
          </button>

          <div class="yt-btn-group-row" style="margin-top: 8px;">
            <button id="yt-action-copy" class="yt-btn yt-btn-outline" title="Copy comma separated tags list">
              Copy Tags
            </button>
            <button id="yt-action-clear" class="yt-btn yt-btn-outline" title="Clear all tags">
              Clear All
            </button>
          </div>
        </div>
      </div>
      `:a=`
        <div class="yt-sidebar-wrapper" style="justify-content: center; text-align: center; padding: 20px;">
          <h2 style="color: white; margin-bottom: 12px; font-family: 'Outfit', sans-serif;">VidRank is Locked</h2>
          <p style="color: #aaaaaa; font-size: 13px; line-height: 1.5; margin-bottom: 24px;">Please sign in with Google to unlock all features.</p>
          <button id="yt-sidebar-btn-login" style="background: white; color: black; border-radius: 8px; padding: 12px; width: 100%; border: none; font-weight: 600; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 10px; font-family: 'Outfit', sans-serif; font-size: 14px;">
            <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
            Sign in with Google
          </button>
          <div id="yt-sidebar-login-error" style="color: #ff4444; margin-top: 15px; font-size: 12px; display: none;"></div>
        </div>
      `,e.innerHTML=`
      <!-- Collapsible trigger tab -->
      <button id="yt-sidebar-toggle-btn" class="yt-sidebar-toggle-btn" title="Toggle Tag Generator">
        <img src="${chrome.runtime.getURL("assets/icons/logo.png")}" width="20" height="20" alt="VidRank Logo">
        <span class="badge" id="yt-sidebar-badge-count" style="display: none;">0</span>
      </button>

      <!-- Sidebar Content Wrapper -->
      <div class="yt-sidebar-wrapper">
        ${a}
      </div>
    `,document.body.appendChild(e),this.element=e,this.attachEventListeners(),this.isLoggedIn&&this.refreshProfile()}refreshProfile(){chrome.storage.local.get({displayName:"",email:"",photoURL:"",isLoggedIn:!1},async t=>{if(!t.isLoggedIn)return;const e=document.getElementById("yt-sidebar-avatar"),a=document.getElementById("yt-sidebar-profile-name"),n=document.getElementById("yt-sidebar-tier"),i=document.getElementById("yt-sidebar-usage");if(!e||!a||!n||!i)return;if(t.photoURL)e.innerHTML=`<img src="${t.photoURL}" alt="" referrerpolicy="no-referrer" />`;else{const s=String(t.displayName||t.email||"V").trim().charAt(0).toUpperCase();e.innerHTML=`<span class="yt-avatar-letter">${s}</span>`}a.textContent=t.displayName||t.email||"VidRank User";const l=await this.getQuota(),r=l&&l.plan==="pro";n.textContent=r?"PRO":"FREE",n.className=r?"yt-tier-pill yt-tier-pill-pro":"yt-tier-pill yt-tier-pill-free";const d=l&&l.usageLimit!=null&&l.usageLimit>0?l.usageLimit:10,c=l&&l.remaining!=null?l.remaining:d;i.textContent=r?"Unlimited":`${c} / ${d}`})}attachEventListeners(){const t=document.getElementById("yt-sidebar-toggle-btn");if(!this.isLoggedIn){t.addEventListener("click",()=>{this.isOpen=!this.isOpen,this.element.classList.toggle("open",this.isOpen)});const s=document.getElementById("yt-sidebar-btn-login"),o=document.getElementById("yt-sidebar-login-error");s&&s.addEventListener("click",()=>{s.disabled=!0,s.style.opacity="0.7",o.style.display="none",chrome.runtime.sendMessage({action:"login"},g=>{var y;s.disabled=!1,s.style.opacity="1",(chrome.runtime.lastError||!g||!g.success)&&(o.textContent=(g==null?void 0:g.error)||((y=chrome.runtime.lastError)==null?void 0:y.message)||"Login failed.",o.style.display="block")})});return}const e=document.getElementById("yt-toggle-insert"),a=document.getElementById("yt-toggle-hashtag"),n=document.getElementById("yt-action-regenerate"),i=document.getElementById("yt-action-insert"),l=document.getElementById("yt-action-copy"),r=document.getElementById("yt-action-clear"),d=document.getElementById("yt-manual-tag-input"),c=document.getElementById("yt-manual-tag-add-btn");t.addEventListener("click",()=>{this.isOpen=!this.isOpen,this.element.classList.toggle("open",this.isOpen),this.isOpen&&(document.getElementById("yt-sidebar-badge-count").style.display="none")}),e.addEventListener("change",s=>{const o=s.target.checked;chrome.storage.sync.set({autoInsert:o},()=>{this.log(`Auto Insert toggled: ${o}`,"success")})}),a&&a.addEventListener("change",s=>{const o=s.target.checked;chrome.storage.sync.set({hashtagMode:o},()=>{this.log(`Hashtag Mode toggled: ${o}`,"success"),this.updateTagsList(this.tags),this.onToggleHashtag(o)})}),this.checkAndApplyPaywall(),n.addEventListener("click",async()=>{const s=await this.getQuota(),o=await new Promise(p=>chrome.storage.local.get({uid:""},p)),g=s&&s.usageCount||0,y=s&&s.plan||"free",b=s&&s.usageLimit!=null?s.usageLimit:-1,v=o.uid||"";if(y==="free"&&b>=0&&g>=b){window.open(`https://www.vidrank.tech/?userId=${v}`,"_blank");return}const m=s&&s.retry_after||0,f=m>0&&m<=120?m:0;if(y==="free"&&f>0){let p=f;n.disabled=!0;const x=n.innerHTML;n.innerHTML=`<span>Wait ${p}s...</span>`;const T=setInterval(()=>{p--,p>0?n.innerHTML=`<span>Wait ${p}s...</span>`:(clearInterval(T),n.innerHTML=x,n.disabled=!1,this.log("Regenerate tags manually requested.","info"),this.onRegenerate())},1e3);return}n.disabled=!0;const w=n.innerHTML;n.innerHTML='<span class="yt-btn-spinner"></span> Regenerating...';try{this.log("Regenerate tags manually requested.","info"),await this.onRegenerate()}finally{n.disabled=!1,n.innerHTML=w}}),i.addEventListener("click",()=>{this.log("Manual tags placement started...","info"),this.onInsertTags(this.tags)}),l.addEventListener("click",()=>{this.copyTagsToClipboard()}),r.addEventListener("click",()=>{this.clearTags()}),d.addEventListener("keydown",s=>{s.key==="Enter"&&this.addManualTag()}),c.addEventListener("click",()=>{this.addManualTag()}),chrome.storage.onChanged.addListener((s,o)=>{o==="sync"&&(s.autoInsert&&(e.checked=s.autoInsert.newValue),s.hashtagMode&&a&&(a.checked=s.hashtagMode.newValue,this.updateTagsList(this.tags)),s.maxTagsCount&&(document.getElementById("yt-max-tags-limit").textContent=s.maxTagsCount.newValue))})}getQuota(){return new Promise(t=>{chrome.runtime.sendMessage({action:"getQuota"},e=>{t(e&&e.success?e.stats:null)})})}log(){}updateDetectedTitle(t){const e=document.getElementById("yt-sidebar-detected-title");e&&(e.textContent=t||"Waiting for video details...",e.title=t)}checkAndApplyPaywall(){this.getQuota().then(t=>{const e=(t&&t.plan||"free")==="free",a=t&&t.usageLimit!=null?t.usageLimit:-1,n=t&&t.usageCount||0,i=typeof(t==null?void 0:t.remaining)=="number"&&t.remaining>=0?t.remaining:Math.max(0,a-n);e&&a>=0&&(i<=0||n>=a)?this.applyPaywallOverlay():this.removePaywallOverlay()})}removePaywallOverlay(){if(!this.element)return;const t=this.element.querySelector(".yt-sidebar-wrapper");t&&(t.style.filter="none",t.style.pointerEvents="auto",t.style.userSelect="auto");const e=this.element.querySelector(".yt-paywall-overlay");e&&e.remove()}applyPaywallOverlay(){const t=this.element.querySelector(".yt-sidebar-wrapper");if(!t||this.element.querySelector(".yt-paywall-overlay"))return;t.style.filter="blur(6px)",t.style.pointerEvents="none",t.style.userSelect="none";const e=document.createElement("div");e.className="yt-paywall-overlay",e.style.position="absolute",e.style.top="0",e.style.left="0",e.style.width="100%",e.style.height="100%",e.style.display="flex",e.style.flexDirection="column",e.style.justifyContent="center",e.style.alignItems="center",e.style.background="rgba(15, 15, 15, 0.2)",e.style.zIndex="1000",e.style.padding="20px",e.style.textAlign="center",e.style.boxSizing="border-box",e.innerHTML=`
      <div style="background: #181818; padding: 32px 24px; border-radius: 16px; border: 1px solid rgba(255, 215, 0, 0.4); box-shadow: 0 16px 40px rgba(0,0,0,0.5), 0 0 40px rgba(255, 215, 0, 0.1); width: 100%; box-sizing: border-box;">
        <svg viewBox="0 0 24 24" width="56" height="56" fill="#FFD700" style="margin-bottom: 20px; filter: drop-shadow(0 0 8px rgba(255, 215, 0, 0.4));">
          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
        </svg>
        <h2 style="color: #FFD700; margin-bottom: 16px; font-family: 'Outfit', sans-serif; font-size: 22px; font-weight: 700; letter-spacing: 0.5px;">Limit Reached</h2>
        <p style="color: #e0e0e0; font-size: 14px; line-height: 1.6; margin-bottom: 28px; font-family: 'Outfit', sans-serif;">You've used all your free optimizations for today.<br><br>Unlock unlimited generations and higher rankings instantly.</p>
        <button id="yt-sidebar-btn-upgrade-overlay" style="background: linear-gradient(135deg, #FFD700 0%, #FDB931 100%); color: #000; border-radius: 10px; padding: 14px 20px; border: none; font-weight: 700; cursor: pointer; font-family: 'Outfit', sans-serif; font-size: 15px; text-transform: uppercase; letter-spacing: 0.8px; width: 100%; box-shadow: 0 6px 20px rgba(255, 215, 0, 0.35); transition: all 0.2s ease;">
          ⭐ Upgrade to Pro
        </button>
      </div>
    `,this.element.appendChild(e);const a=document.getElementById("yt-sidebar-btn-upgrade-overlay");a.addEventListener("mouseenter",()=>{a.style.transform="translateY(-2px)",a.style.boxShadow="0 8px 25px rgba(255, 215, 0, 0.5)"}),a.addEventListener("mouseleave",()=>{a.style.transform="translateY(0)",a.style.boxShadow="0 6px 20px rgba(255, 215, 0, 0.35)"}),a.addEventListener("click",()=>{chrome.storage.local.get(["uid"],n=>{const i=n.uid||"";window.open(`https://www.vidrank.tech/?userId=${i}`,"_blank")})})}updateTagsList(t){this.tags=t;const e=document.getElementById("yt-chips-container"),a=document.getElementById("yt-sidebar-badge-count"),n=document.querySelector(".yt-tags-placeholder-tip");if(!e)return;if(e.innerHTML="",this.tags.length===0){n.style.display="block",a.style.display="none",this.updateCounters(0,0);return}n.style.display="none",this.isOpen||(a.textContent=this.tags.length,a.style.display="block");const i=document.getElementById("yt-toggle-hashtag"),l=i?i.checked:!1;let r=this.tags;l&&typeof u=="function"&&(r=u(this.tags));let d=0;r.forEach((c,s)=>{d+=c.length,s>0&&(d+=1);const o=document.createElement("div");o.className="yt-tag-chip",o.innerHTML=`
        <span class="yt-chip-label" title="Copy individual tag">${c}</span>
        <button class="yt-chip-delete-btn" data-index="${s}" title="Remove tag">×</button>
      `,o.querySelector(".yt-chip-label").addEventListener("click",()=>{navigator.clipboard.writeText(c).then(()=>{this.log(`Copied tag: "${c}"`,"success")})}),o.querySelector(".yt-chip-delete-btn").addEventListener("click",g=>{const y=parseInt(g.target.getAttribute("data-index"),10);this.removeTag(y)}),e.appendChild(o)}),this.updateCounters(r.length,d),document.getElementById("yt-last-update-time").textContent=new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}updateCounters(t,e){document.getElementById("yt-tag-counter").textContent=t;const a=document.getElementById("yt-char-counter");a.textContent=e,e>480?a.style.color="#ff4d4d":a.style.color=""}addManualTag(){const t=document.getElementById("yt-manual-tag-input"),e=t.value.trim().toLowerCase();if(!e)return;if(this.tags.includes(e)){this.log(`Tag "${e}" already exists in the list.`,"warning"),t.value="";return}const a=e.split(",").map(i=>i.trim()).filter(i=>i.length>0);let n=0;chrome.storage.sync.get({maxTagsCount:35},i=>{const l=i.maxTagsCount,r=[...this.tags];for(const d of a){if(r.length>=l){this.log(`Tag limit of ${l} reached. Cannot add "${d}".`,"warning");break}const c=r.join(",").length+(r.length>0?1:0),s=d.length+1;if(c+s>495){this.log(`YouTube 500-char limits exceeded. Skipping tag "${d}".`,"warning");break}r.includes(d)||(r.push(d),n++)}n>0&&(t.value="",this.updateTagsList(r),this.log(`Manually added ${n} custom tag(s).`,"success"),document.getElementById("yt-toggle-insert").checked&&this.onInsertTags(this.tags))})}removeTag(t){const e=this.tags[t],a=this.tags.filter((n,i)=>i!==t);this.updateTagsList(a),this.log(`Removed tag: "${e}"`,"warning"),document.getElementById("yt-toggle-insert").checked&&this.onInsertTags(this.tags)}clearTags(){this.updateTagsList([]),this.log("All tags cleared.","warning")}copyTagsToClipboard(){if(this.tags.length===0){this.log("No tags available to copy.","warning");return}chrome.storage.sync.get({preferredSeparator:","},t=>{const e=t.preferredSeparator||",",a=document.getElementById("yt-toggle-hashtag"),n=a?a.checked:!1;let i=this.tags;n&&typeof u=="function"&&(i=u(this.tags));const l=i.join(e);navigator.clipboard.writeText(l).then(()=>{this.log(`Copied ${i.length} tags to clipboard.`,"success")}).catch(r=>{this.log(`Clipboard copy failed: ${r.message}`,"error")})})}}window.YouTubeStudioUI=L;
})()
